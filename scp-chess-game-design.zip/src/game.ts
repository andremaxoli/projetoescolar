export type Side = 'foundation' | 'chaos';
export type Kind = 'king' | 'queen' | 'rook' | 'bishop' | 'knight' | 'pawn';
export type Position = { r: number; c: number };
export type Piece = {
  id: string;
  side: Side;
  kind: Kind;
  moved: boolean;
  cooldown: number;
  armor?: boolean;
};
export type Board = (Piece | null)[][];
export type Move = { from: Position; to: Position; special: boolean; capture?: Piece; notation: string };
export type Game = {
  board: Board;
  turn: Side;
  enPassant: Position | null;
  moves: Move[];
  lastMove: Move | null;
  breachStreak: number;
  winner: Side | null;
  outcome: string;
};

export const CELLS: Position[] = [{ r: 3, c: 4 }, { r: 4, c: 3 }];
export const other = (side: Side): Side => side === 'foundation' ? 'chaos' : 'foundation';
export const same = (a: Position, b: Position) => a.r === b.r && a.c === b.c;
export const inside = (r: number, c: number) => r >= 0 && r < 8 && c >= 0 && c < 8;
export const square = (p: Position) => `${'abcdefgh'[p.c]}${8 - p.r}`;
export const cloneBoard = (board: Board): Board => board.map(row => row.map(piece => piece ? { ...piece } : null));

export function initialGame(): Game {
  const board: Board = Array.from({ length: 8 }, () => Array<Piece | null>(8).fill(null));
  const back: Kind[] = ['rook', 'knight', 'bishop', 'queen', 'king', 'bishop', 'knight', 'rook'];
  for (let c = 0; c < 8; c++) {
    board[0][c] = { id: `c-${back[c]}-${c}`, side: 'chaos', kind: back[c], moved: false, cooldown: 0, ...(c === 3 ? { armor: true } : {}) };
    board[1][c] = { id: `c-pawn-${c}`, side: 'chaos', kind: 'pawn', moved: false, cooldown: 0 };
    board[6][c] = { id: `f-pawn-${c}`, side: 'foundation', kind: 'pawn', moved: false, cooldown: 0 };
    board[7][c] = { id: `f-${back[c]}-${c}`, side: 'foundation', kind: back[c], moved: false, cooldown: 0 };
  }
  return { board, turn: 'foundation', enPassant: null, moves: [], lastMove: null, breachStreak: 0, winner: null, outcome: '' };
}

function ray(board: Board, from: Position, dirs: number[][], max = 7): Position[] {
  const piece = board[from.r][from.c];
  if (!piece) return [];
  const result: Position[] = [];
  for (const [dr, dc] of dirs) {
    for (let n = 1; n <= max; n++) {
      const r = from.r + dr * n, c = from.c + dc * n;
      if (!inside(r, c)) break;
      const target = board[r][c];
      if (!target) result.push({ r, c });
      else {
        if (target.side !== piece.side && target.kind !== 'king') result.push({ r, c });
        break;
      }
    }
  }
  return result;
}

const straight = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const diagonal = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
const allDirs = [...straight, ...diagonal];
const knightJumps = [[1, 2], [1, -2], [-1, 2], [-1, -2], [2, 1], [2, -1], [-2, 1], [-2, -1]];

function jumps(board: Board, from: Position, offsets: number[][], captureOnly = false): Position[] {
  const piece = board[from.r][from.c];
  if (!piece) return [];
  return offsets.map(([dr, dc]) => ({ r: from.r + dr, c: from.c + dc }))
    .filter(p => inside(p.r, p.c) && (!board[p.r][p.c] ? !captureOnly : board[p.r][p.c]?.side !== piece.side && board[p.r][p.c]?.kind !== 'king'));
}

// Attack detection is separate from movement so pawn pushes and castling never count as attacks.
export function isAttacked(board: Board, target: Position, by: Side): boolean {
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    const piece = board[r][c];
    if (!piece || piece.side !== by) continue;
    const dr = target.r - r, dc = target.c - c;
    if (piece.kind === 'pawn' && dr === (by === 'foundation' ? -1 : 1) && Math.abs(dc) === 1) return true;
    if (piece.kind === 'knight' && ((Math.abs(dr) === 2 && Math.abs(dc) === 1) || (Math.abs(dr) === 1 && Math.abs(dc) === 2))) return true;
    if (piece.kind === 'king' && Math.max(Math.abs(dr), Math.abs(dc)) === 1) return true;
    const orthogonal = (dr === 0 || dc === 0) && (dr !== 0 || dc !== 0);
    const diag = Math.abs(dr) === Math.abs(dc) && dr !== 0;
    if (!((piece.kind === 'queen' && (orthogonal || diag)) || (piece.kind === 'rook' && orthogonal) || (piece.kind === 'bishop' && diag))) continue;
    const stepR = Math.sign(dr), stepC = Math.sign(dc);
    let rr = r + stepR, cc = c + stepC, clear = true;
    while (rr !== target.r || cc !== target.c) {
      if (board[rr][cc]) { clear = false; break; }
      rr += stepR; cc += stepC;
    }
    if (clear) return true;
  }
  return false;
}

export function kingPosition(board: Board, side: Side): Position {
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++)
    if (board[r][c]?.side === side && board[r][c]?.kind === 'king') return { r, c };
  throw new Error('King missing from board');
}

export function inCheck(board: Board, side: Side): boolean {
  return isAttacked(board, kingPosition(board, side), other(side));
}

function normalMoves(game: Game, from: Position): Position[] {
  const { board } = game;
  const piece = board[from.r][from.c];
  if (!piece) return [];
  if (piece.kind === 'queen') return ray(board, from, allDirs);
  if (piece.kind === 'rook') return ray(board, from, straight);
  if (piece.kind === 'bishop') return ray(board, from, diagonal);
  if (piece.kind === 'knight') return jumps(board, from, knightJumps);
  if (piece.kind === 'pawn') {
    const dir = piece.side === 'foundation' ? -1 : 1;
    const result: Position[] = [];
    if (inside(from.r + dir, from.c) && !board[from.r + dir][from.c]) {
      result.push({ r: from.r + dir, c: from.c });
      if (!piece.moved && !board[from.r + dir * 2][from.c]) result.push({ r: from.r + dir * 2, c: from.c });
    }
    for (const dc of [-1, 1]) {
      const r = from.r + dir, c = from.c + dc;
      if (!inside(r, c)) continue;
      const target = board[r][c];
      if ((target && target.side !== piece.side && target.kind !== 'king') || (game.enPassant && same(game.enPassant, { r, c }))) result.push({ r, c });
    }
    return result;
  }
  const result = jumps(board, from, allDirs);
  if (!piece.moved && !inCheck(board, piece.side)) {
    for (const rookCol of [0, 7]) {
      const rook = board[from.r][rookCol];
      const dir = rookCol === 0 ? -1 : 1;
      if (!rook || rook.kind !== 'rook' || rook.side !== piece.side || rook.moved) continue;
      let empty = true;
      for (let c = from.c + dir; c !== rookCol; c += dir) if (board[from.r][c]) empty = false;
      if (empty && !isAttacked(board, { r: from.r, c: from.c + dir }, other(piece.side))) result.push({ r: from.r, c: from.c + dir * 2 });
    }
  }
  return result;
}

function specialMoves(game: Game, from: Position): Position[] {
  const { board } = game;
  const piece = board[from.r][from.c];
  if (!piece || piece.kind === 'pawn' || piece.cooldown > 0) return [];
  const { side, kind } = piece;
  if (side === 'foundation') {
    if (kind === 'queen') return jumps(board, from, knightJumps);
    if (kind === 'bishop') return jumps(board, from, straight.map(([r, c]) => [r * 2, c * 2]));
    if (kind === 'knight') return jumps(board, from, [[3, 1], [3, -1], [-3, 1], [-3, -1], [1, 3], [1, -3], [-1, 3], [-1, -3]]);
    if (kind === 'rook') return ray(board, from, diagonal, 1);
    if (kind === 'king') return straight.map(([dr, dc]) => ({ r: from.r + dr * 2, c: from.c + dc * 2 }))
      .filter(p => inside(p.r, p.c) && !board[from.r + Math.sign(p.r - from.r)][from.c + Math.sign(p.c - from.c)] &&
        !isAttacked(board, { r: from.r + Math.sign(p.r - from.r), c: from.c + Math.sign(p.c - from.c) }, other(side)) &&
        (!board[p.r][p.c] || (board[p.r][p.c]?.side !== side && board[p.r][p.c]?.kind !== 'king')));
  }
  if (kind === 'queen') return jumps(board, from, allDirs.map(([r, c]) => [r * 2, c * 2]));
  if (kind === 'bishop') return isAttacked(board, from, 'foundation') ? ray(board, from, allDirs, 3) : [];
  if (kind === 'knight') {
    const observed = allDirs.some(([dr, dc]) => inside(from.r + dr, from.c + dc) && board[from.r + dr][from.c + dc]?.side === 'foundation');
    return observed ? [] : jumps(board, from, straight.map(([r, c]) => [r * 2, c * 2]));
  }
  if (kind === 'rook') return jumps(board, from, [...allDirs, ...allDirs.map(([r, c]) => [r * 2, c * 2])]);
  return straight.map(([dr, dc]) => ({ r: from.r + dr * 2, c: from.c + dc * 2 }))
    .filter(p => inside(p.r, p.c) && !board[from.r + Math.sign(p.r - from.r)][from.c + Math.sign(p.c - from.c)] &&
      !isAttacked(board, { r: from.r + Math.sign(p.r - from.r), c: from.c + Math.sign(p.c - from.c) }, other(side)) &&
      (!board[p.r][p.c] || (board[p.r][p.c]?.side !== side && board[p.r][p.c]?.kind !== 'king')));
}

function simulate(game: Game, from: Position, to: Position, special: boolean): Board {
  const board = cloneBoard(game.board);
  const piece = board[from.r][from.c]!;
  const target = board[to.r][to.c];
  if (target?.armor && piece.side === 'foundation') {
    target.armor = false;
    return board;
  }
  if (piece.kind === 'pawn' && game.enPassant && same(to, game.enPassant) && !target) board[from.r][to.c] = null;
  board[to.r][to.c] = { ...piece, moved: true, cooldown: special ? 4 : piece.cooldown };
  board[from.r][from.c] = null;
  if (piece.kind === 'king' && !special && Math.abs(to.c - from.c) === 2) {
    const rookFrom = to.c > from.c ? 7 : 0;
    const rookTo = to.c > from.c ? to.c - 1 : to.c + 1;
    board[to.r][rookTo] = { ...board[to.r][rookFrom]!, moved: true };
    board[to.r][rookFrom] = null;
  }
  if (piece.kind === 'pawn' && (to.r === 0 || to.r === 7)) board[to.r][to.c] = { ...board[to.r][to.c]!, kind: 'queen', id: `${piece.id}-promoted` };
  return board;
}

export function legalMoves(game: Game, from: Position, special = false): Position[] {
  const piece = game.board[from.r][from.c];
  if (!piece || piece.side !== game.turn || game.winner || game.outcome) return [];
  return (special ? specialMoves(game, from) : normalMoves(game, from)).filter(to => !inCheck(simulate(game, from, to, special), piece.side));
}

function hasMove(game: Game): boolean {
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    if (game.board[r][c]?.side === game.turn && (legalMoves(game, { r, c }).length || legalMoves(game, { r, c }, true).length)) return true;
  }
  return false;
}

export function makeMove(game: Game, from: Position, to: Position, special: boolean): Game {
  const piece = game.board[from.r][from.c]!;
  const armored = !!game.board[to.r][to.c]?.armor && piece.side === 'foundation';
  const enPassantCapture = piece.kind === 'pawn' && !!game.enPassant && same(to, game.enPassant) && !game.board[to.r][to.c];
  const capture = game.board[to.r][to.c] || (enPassantCapture ? game.board[from.r][to.c] : null);
  const board = simulate(game, from, to, special);
  const letter = { king: 'R', queen: 'D', rook: 'T', bishop: 'B', knight: 'C', pawn: '' }[piece.kind];
  const notation = armored ? `${letter}${square(from)}!682` : `${letter}${square(from)}${capture ? 'x' : '-'}${square(to)}${special ? '*' : ''}${piece.kind === 'pawn' && (to.r === 0 || to.r === 7) ? '=D' : ''}`;
  const move: Move = { from, to, special, capture: armored ? undefined : capture || undefined, notation };
  const turn = other(game.turn);
  for (const row of board) for (const item of row) if (item?.side === turn && item.cooldown > 0) item.cooldown--;
  const next: Game = {
    ...game, board, turn, lastMove: move, moves: [...game.moves, move],
    enPassant: !armored && piece.kind === 'pawn' && Math.abs(to.r - from.r) === 2 ? { r: (to.r + from.r) / 2, c: from.c } : null,
  };
  const blackMajorsRemaining = board.flat().filter(p => p?.side === 'chaos' && p.kind !== 'pawn' && p.kind !== 'king').length;
  const whiteControls = CELLS.every(p => board[p.r][p.c]?.side === 'foundation');
  const blackControls = CELLS.every(p => board[p.r][p.c]?.side === 'chaos' && board[p.r][p.c]?.kind !== 'pawn' && board[p.r][p.c]?.kind !== 'king');
  next.breachStreak = game.turn === 'chaos' ? (blackControls ? game.breachStreak + 1 : 0) : game.breachStreak;
  if (game.turn === 'foundation' && whiteControls && blackMajorsRemaining <= 5) {
    next.winner = 'foundation'; next.outcome = 'Contenção Total';
  } else if (game.turn === 'chaos' && next.breachStreak >= 2) {
    next.winner = 'chaos'; next.outcome = 'Ruptura Total';
  } else if (!hasMove(next)) {
    if (inCheck(board, turn)) {
      next.winner = game.turn;
      next.outcome = game.turn === 'chaos' ? 'Brecha de Contenção Total' : 'Xeque-mate';
    } else next.outcome = 'Empate por afogamento';
  }
  return next;
}
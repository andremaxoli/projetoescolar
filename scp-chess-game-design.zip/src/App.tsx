import { useMemo, useState } from 'react';
import { Activity, BookOpen, ChevronLeft, ChevronRight, CircleHelp, Clipboard, Code2, Crosshair, Flag, Menu, RotateCcw, Shield, ShieldAlert, Swords, Target, X } from 'lucide-react';
import { CELLS, initialGame, inCheck, legalMoves, makeMove, other, same, square, type Game, type Kind, type Piece, type Position, type Side } from './game';
import './index.css';

type Tab = 'game' | 'rules' | 'code';
const glyphs: Record<Side, Record<Kind, string>> = {
  foundation: { king: '♚', queen: '♛', rook: '♜', bishop: '♝', knight: '♞', pawn: '♟' },
  chaos: { king: '♚', queen: '♛', rook: '♜', bishop: '♝', knight: '♞', pawn: '♟' },
};
const names: Record<Side, Record<Kind, string>> = {
  foundation: { king: 'Diretor do Sítio', queen: 'Conselho O5', rook: 'Porta de Contenção', bishop: 'Pesquisador Nível 4', knight: 'Agente MTF', pawn: 'Guarda de Segurança' },
  chaos: { king: 'Comandante da Insurgência', queen: 'SCP-682', rook: 'SCP-106', bishop: 'SCP-096', knight: 'SCP-173', pawn: 'Operativo Insurgente' },
};
const abilities: Record<Side, Record<Kind, { name: string; description: string }>> = {
  foundation: {
    king: { name: 'Evacuação de emergência', description: 'Avança 2 casas em linha reta, com passagem livre e segura.' },
    queen: { name: 'Ordem prioritária', description: 'Salta em L como um agente MTF.' },
    rook: { name: 'Porta lateral', description: 'Desloca-se 1 casa na diagonal.' },
    bishop: { name: 'Atalho técnico', description: 'Salta exatamente 2 casas em linha reta.' },
    knight: { name: 'Inserção tática', description: 'Salta 3 casas num eixo e 1 no outro.' },
    pawn: { name: 'Sem habilidade ativa', description: 'Avança e captura como um peão clássico.' },
  },
  chaos: {
    king: { name: 'Extração clandestina', description: 'Avança 2 casas em linha reta, com passagem livre e segura.' },
    queen: { name: 'Adaptação', description: 'SCP-682 salta exatamente 2 casas em qualquer direção.' },
    rook: { name: 'Travessia dimensional', description: 'SCP-106 salta até 2 casas em qualquer direção.' },
    bishop: { name: 'Gatilho de fúria', description: 'Se estiver sob ataque, SCP-096 move até 3 casas como uma dama.' },
    knight: { name: 'Avanço sem observador', description: 'Se não houver inimigo adjacente, SCP-173 salta 2 casas em linha reta.' },
    pawn: { name: 'Sem habilidade ativa', description: 'Avança e captura como um peão clássico.' },
  },
};
const equivalences: { kind: Kind; classic: string; white: string; black: string }[] = [
  { kind: 'king', classic: 'Rei', white: 'Diretor do Sítio', black: 'Comandante' },
  { kind: 'queen', classic: 'Dama', white: 'Conselho O5', black: 'SCP-682' },
  { kind: 'rook', classic: 'Torre', white: 'Porta de Contenção', black: 'SCP-106' },
  { kind: 'bishop', classic: 'Bispo', white: 'Pesquisador Nível 4', black: 'SCP-096' },
  { kind: 'knight', classic: 'Cavalo', white: 'Agente MTF', black: 'SCP-173' },
  { kind: 'pawn', classic: 'Peão', white: 'Guarda', black: 'Operativo Insurgente' },
];

const pythonCode = `from dataclasses import dataclass
from enum import Enum

class Faccao(Enum):
    FUNDACAO = "fundacao"
    CAOS = "caos"

@dataclass
class Peca:
    tipo: str
    faccao: Faccao
    linha: int
    coluna: int
    cooldown: int = 0
    moveu: bool = False

    def movimentos_validos(self, tabuleiro):
        """Gera candidatos; o motor filtra xeques depois."""
        direcoes = {
            "torre": [(1,0), (-1,0), (0,1), (0,-1)],
            "bispo": [(1,1), (1,-1), (-1,1), (-1,-1)],
        }
        if self.tipo == "dama":
            vetores = direcoes["torre"] + direcoes["bispo"]
            alcance = 7
        elif self.tipo in direcoes:
            vetores = direcoes[self.tipo]
            alcance = 7
        elif self.tipo == "cavalo":
            vetores = [(1,2),(1,-2),(-1,2),(-1,-2),
                       (2,1),(2,-1),(-2,1),(-2,-1)]
            alcance = 1
        elif self.tipo == "rei":
            vetores = direcoes["torre"] + direcoes["bispo"]
            alcance = 1
        else:
            return self.movimentos_peao(tabuleiro)

        possiveis = []
        for dl, dc in vetores:
            for passo in range(1, alcance + 1):
                l, c = self.linha + dl*passo, self.coluna + dc*passo
                if not (0 <= l < 8 and 0 <= c < 8):
                    break
                alvo = tabuleiro[l][c]
                if alvo is None:
                    possiveis.append((l, c))
                else:
                    if alvo.faccao != self.faccao and alvo.tipo != "rei":
                        possiveis.append((l, c))
                    break
        return possiveis

    def movimentos_peao(self, tabuleiro):
        sentido = -1 if self.faccao == Faccao.FUNDACAO else 1
        l, c = self.linha, self.coluna
        saida = []
        if 0 <= l + sentido < 8 and tabuleiro[l+sentido][c] is None:
            saida.append((l+sentido, c))
            if not self.moveu and tabuleiro[l+2*sentido][c] is None:
                saida.append((l+2*sentido, c))
        for dc in (-1, 1):
            if 0 <= c+dc < 8 and 0 <= l+sentido < 8:
                alvo = tabuleiro[l+sentido][c+dc]
                if alvo and alvo.faccao != self.faccao and alvo.tipo != "rei":
                    saida.append((l+sentido, c+dc))
        return saida

def movimento_legal(peca, destino, tabuleiro, em_xeque):
    if destino not in peca.movimentos_validos(tabuleiro):
        return False
    copia = [[celula for celula in linha] for linha in tabuleiro]
    copia[peca.linha][peca.coluna] = None
    copia[destino[0]][destino[1]] = peca
    return not em_xeque(copia, peca.faccao)

# Habilidades ativas: gere destinos extras por tipo de SCP,
# verifique cooldown == 0 e aplique o mesmo filtro de xeque.
# Ao usar: cooldown = 4; reduza 1 no inicio de cada turno
# da propria faccao. Protecao inicial do SCP-682 absorve
# a primeira captura valida, consumindo o turno do atacante.`;

function PieceIcon({ piece, small = false }: { piece: Piece; small?: boolean }) {
  return <span className={`piece piece-${piece.side} ${small ? 'piece-small' : ''}`} aria-label={names[piece.side][piece.kind]}>
    <span className="piece-glyph">{glyphs[piece.side][piece.kind]}</span>
    {piece.side === 'chaos' && piece.kind !== 'pawn' && piece.kind !== 'king' && !small && <span className="piece-id">{({ queen: '682', rook: '106', bishop: '096', knight: '173' } as Record<string, string>)[piece.kind]}</span>}
    {piece.armor && !small && <span className="armor-dot" />}
  </span>;
}

function Logo({ compact = false }: { compact?: boolean }) {
  return <div className={`logo-mark ${compact ? 'logo-compact' : ''}`} aria-label="SCP Chess"><div className="logo-inner"><Crosshair size={compact ? 20 : 25} strokeWidth={2.2} /></div></div>;
}

function PlayerBar({ side, game, active }: { side: Side; game: Game; active: boolean }) {
  const isFoundation = side === 'foundation';
  const captured = game.moves.filter(m => m.capture?.side === other(side)).map(m => m.capture!);
  return <div className="player-bar">
    <div className={`player-avatar ${isFoundation ? 'avatar-foundation' : 'avatar-chaos'}`}>{isFoundation ? <Shield size={21} strokeWidth={2.2} /> : <ShieldAlert size={21} strokeWidth={2.2} />}</div>
    <div className="player-info"><div className="player-name">{isFoundation ? 'Fundação SCP' : 'Insurgência do Caos'} <span className={`player-indicator ${active ? 'on' : ''}`} /></div><div className="player-sub">{isFoundation ? 'Protocolo de contenção' : 'Anomalias livres'} <span className="captured-pieces">{captured.map((p, i) => <span key={i}>{glyphs[p.side][p.kind]}</span>)}</span></div></div>
    <div className={`turn-label ${active ? 'turn-active' : ''}`}>{active ? 'SUA VEZ' : 'AGUARDANDO'}</div>
  </div>;
}

export default function App() {
  const [game, setGame] = useState<Game>(() => initialGame());
  const [past, setPast] = useState<Game[]>([]);
  const [selected, setSelected] = useState<Position | null>(null);
  const [abilityMode, setAbilityMode] = useState(false);
  const [tab, setTab] = useState<Tab>('game');
  const [flipped, setFlipped] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [copied, setCopied] = useState(false);
  const [confirmResign, setConfirmResign] = useState(false);

  const currentPiece = selected ? game.board[selected.r][selected.c] : null;
  const normal = useMemo(() => selected ? legalMoves(game, selected) : [], [game, selected]);
  const special = useMemo(() => selected ? legalMoves(game, selected, true) : [], [game, selected]);
  const targets = abilityMode ? special : normal;
  const rows = flipped ? [7, 6, 5, 4, 3, 2, 1, 0] : [0, 1, 2, 3, 4, 5, 6, 7];
  const cols = flipped ? [7, 6, 5, 4, 3, 2, 1, 0] : [0, 1, 2, 3, 4, 5, 6, 7];
  const movePairs = Array.from({ length: Math.ceil(game.moves.length / 2) }, (_, i) => game.moves.slice(i * 2, i * 2 + 2));
  const blackCaptured = 7 - game.board.flat().filter(p => p?.side === 'chaos' && p.kind !== 'pawn' && p.kind !== 'king').length;

  function resetSelection() { setSelected(null); setAbilityMode(false); }
  function onSquare(pos: Position) {
    if (game.outcome) return;
    const piece = game.board[pos.r][pos.c];
    if (selected && targets.some(p => same(p, pos))) {
      setPast(prev => [...prev, game]);
      setGame(makeMove(game, selected, pos, abilityMode));
      resetSelection();
      return;
    }
    if (piece?.side === game.turn) {
      if (selected && same(selected, pos)) resetSelection();
      else { setSelected(pos); setAbilityMode(false); }
    } else resetSelection();
  }
  function newGame() { setGame(initialGame()); setPast([]); resetSelection(); setConfirmResign(false); setTab('game'); }
  function undo() { if (!past.length) return; setGame(past[past.length - 1]); setPast(past.slice(0, -1)); resetSelection(); }
  function resign() { setGame({ ...game, winner: other(game.turn), outcome: 'Desistência' }); setConfirmResign(false); resetSelection(); }
  async function copyCode() { await navigator.clipboard.writeText(pythonCode); setCopied(true); window.setTimeout(() => setCopied(false), 2000); }

  return <div className="app-shell">
    <aside className={`sidebar ${showMenu ? 'sidebar-open' : ''}`}>
      <div className="sidebar-brand"><Logo compact /><span>SCP<span className="brand-light">CHESS</span></span></div>
      <div className="sidebar-section-label">OPERAÇÕES</div>
      <button className="side-link active" onClick={() => { setTab('game'); setShowMenu(false); }}><Swords size={19} /> <span>Jogar</span></button>
      <button className="side-link" onClick={() => { setTab('rules'); setShowMenu(false); }}><BookOpen size={19} /> <span>Manual de campo</span></button>
      <button className="side-link" onClick={() => { setTab('code'); setShowMenu(false); }}><Code2 size={19} /> <span>Código-fonte</span></button>
      <div className="sidebar-spacer" />
      <div className="sidebar-bottom"><span className="live-dot" /> SISTEMA OPERACIONAL <span className="sidebar-version">v.01</span></div>
    </aside>

    <main className="main-area">
      <header className="topbar"><div className="topbar-left"><button className="mobile-menu icon-button" onClick={() => setShowMenu(!showMenu)} aria-label="Abrir menu">{showMenu ? <X size={20} /> : <Menu size={20} />}</button><span className="breadcrumb">CENTRAL DE COMANDO</span><ChevronRight size={14} className="bread-chevron" /><span className="breadcrumb-current">Partida local</span></div><div className="topbar-right"><span className="system-status"><span className="live-dot" /> SISTEMA ONLINE</span><span className="topbar-divider" /><span className="session-label">SESSÃO #001</span><div className="top-avatar">O5</div></div></header>

      <div className="content-wrap">
        <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line" /> PROTOCOLO DE ESTRATÉGIA // 001</div><h1>SCP<span> CHESS</span><span className="heading-period">.</span></h1><p>Uma partida. Duas facções. O destino da contenção em jogo.</p></div><button className="new-game-button" onClick={newGame}><span>+</span> Nova partida</button></div>

        <div className="game-layout">
          <section className="board-column" aria-label="Tabuleiro de xadrez SCP">
            <div className="board-topline"><span><span className="topline-dot" /> PARTIDA LOCAL <span className="slash">/</span> 8 × 8</span><span>PROTOCOLO ATIVO <Activity size={14} /></span></div>
            <PlayerBar side={flipped ? 'foundation' : 'chaos'} game={game} active={game.turn === (flipped ? 'foundation' : 'chaos') && !game.outcome} />
            <div className="board-frame"><div className="chessboard" role="grid" aria-label="Tabuleiro 8 por 8">
              {rows.map((r, rowIndex) => cols.map((c, colIndex) => {
                const pos = { r, c }, piece = game.board[r][c];
                const isCell = CELLS.some(cell => same(cell, pos));
                const isSelected = selected && same(selected, pos);
                const isTarget = targets.some(target => same(target, pos));
                const wasLast = game.lastMove && (same(game.lastMove.from, pos) || same(game.lastMove.to, pos));
                const isCheckedKing = piece?.kind === 'king' && piece.side === game.turn && inCheck(game.board, game.turn);
                return <button key={`${r}-${c}`} role="gridcell" aria-label={`${square(pos)}${piece ? `, ${names[piece.side][piece.kind]}` : ''}${isCell ? ', cela de contenção' : ''}`} onClick={() => onSquare(pos)} className={`board-square ${(r + c) % 2 === 0 ? 'square-light' : 'square-dark'} ${isCell ? 'containment-cell' : ''} ${isSelected ? 'selected-square' : ''} ${wasLast ? 'last-square' : ''} ${isCheckedKing ? 'checked-square' : ''}`}>
                  {isCell && <span className="cell-corner cell-tl" />}{isCell && <span className="cell-corner cell-br" />}
                  {colIndex === 0 && <span className="coord rank-coordinate">{8 - r}</span>}
                  {rowIndex === 7 && <span className="coord file-coordinate">{'abcdefgh'[c]}</span>}
                  {piece && <PieceIcon piece={piece} />}
                  {isTarget && <span className={piece ? 'capture-ring' : 'move-dot'} />}
                </button>;
              }))}
            </div></div>
            <PlayerBar side={flipped ? 'chaos' : 'foundation'} game={game} active={game.turn === (flipped ? 'chaos' : 'foundation') && !game.outcome} />
            <div className="board-toolbar"><span><Target size={15} /> <strong>CELAS DE CONTENÇÃO</strong> <i /> e5 <i /> d4</span><div><button title="Voltar um lance" onClick={undo} disabled={!past.length}><RotateCcw size={16} /> <span>Desfazer</span></button><button title="Girar tabuleiro" onClick={() => setFlipped(!flipped)}><Crosshair size={16} /> <span>Girar</span></button></div></div>
          </section>

          <aside className="detail-panel">
            <div className="panel-tabs"><button className={tab === 'game' ? 'active' : ''} onClick={() => setTab('game')}>Partida</button><button className={tab === 'rules' ? 'active' : ''} onClick={() => setTab('rules')}>Regras</button><button className={tab === 'code' ? 'active' : ''} onClick={() => setTab('code')}>Código</button></div>
            {tab === 'game' && <div className="panel-body game-panel">
              <div className="panel-intro"><div className="panel-eyebrow">STATUS DA OPERAÇÃO <span className="small-circle" /></div><h2>{game.outcome ? game.outcome : inCheck(game.board, game.turn) ? 'Xeque ao líder' : game.turn === 'foundation' ? 'Sua vez, Fundação' : 'Sua vez, Insurgência'}</h2><p>{game.outcome ? `${game.winner ? `${game.winner === 'foundation' ? 'A Fundação SCP' : 'A Insurgência'} venceu a partida.` : 'Nenhuma facção venceu a partida.'} Inicie uma nova operação para jogar novamente.` : game.turn === 'foundation' ? 'Proteja o Diretor e assuma o controle das celas.' : 'Rompa os protocolos e avance sobre a instalação.'}</p></div>
              <div className="objective"><div className="objective-head"><Crosshair size={17} /><span>OBJETIVO DE CONTENÇÃO</span><span className="objective-count">{Math.min(blackCaptured, 2)}/2</span></div><div className="progress-track"><div style={{ width: `${Math.min(blackCaptured / 2, 1) * 100}%` }} /></div><p>Capture 2 anomalias principais e ocupe <strong>e5</strong> e <strong>d4</strong> ao fim do turno da Fundação.</p></div>
              <div className="selected-section"><div className="section-heading"><span>PEÇA SELECIONADA</span><CircleHelp size={15} /></div>{currentPiece ? <div className="selection-content"><div className="selection-piece"><PieceIcon piece={currentPiece} small /></div><div className="selection-text"><strong>{names[currentPiece.side][currentPiece.kind]}</strong><span>{square(selected!)} · {currentPiece.side === 'foundation' ? 'Fundação SCP' : 'Insurgência do Caos'}</span></div></div> : <div className="selection-empty"><Crosshair size={21} /><span>Selecione uma peça no tabuleiro para ver suas ações.</span></div>}
                {currentPiece && <div className="ability-area"><div className="ability-copy"><strong>{abilities[currentPiece.side][currentPiece.kind].name}</strong><p>{abilities[currentPiece.side][currentPiece.kind].description}</p></div><button className={`ability-button ${abilityMode ? 'ability-active' : ''}`} disabled={currentPiece.kind === 'pawn' || currentPiece.cooldown > 0 || !special.length} onClick={() => setAbilityMode(!abilityMode)}>{currentPiece.cooldown > 0 ? `RECARGA ${currentPiece.cooldown}` : abilityMode ? 'CANCELAR' : 'ATIVAR'}</button></div>}
              </div>
              <div className="moves-section"><div className="section-heading"><span>REGISTRO DE MOVIMENTOS</span><span>{game.moves.length} LANCES</span></div><div className="moves-list">{movePairs.length ? movePairs.map((pair, i) => <div className="move-row" key={i}><span className="move-index">{String(i + 1).padStart(2, '0')}.</span><span>{pair[0]?.notation}</span><span>{pair[1]?.notation || '...'}</span></div>) : <div className="no-moves">Aguardando o primeiro movimento...</div>}</div></div>
              <div className="panel-actions"><button onClick={undo} disabled={!past.length}><ChevronLeft size={17} /> Desfazer lance</button><button onClick={() => setConfirmResign(true)} disabled={!!game.outcome}><Flag size={16} /> Desistir</button></div>
            </div>}
            {tab === 'rules' && <div className="panel-body rules-panel"><div className="panel-eyebrow">ARQUIVO // REGRAS DO JOGO</div><h2>Manual de campo</h2><p className="rules-lead">Xadrez clássico, protocolos extraordinários. Jogue localmente em turnos alternados: a Fundação começa.</p>
              <div className="rule-block"><h3>01 / Facções e equivalências</h3><div className="equivalence-head"><span>PEÇA</span><span>FUNDAÇÃO</span><span>CAOS</span></div>{equivalences.map(row => <div className="equivalence-row" key={row.kind}><span>{row.classic}</span><span>{row.white}</span><span>{row.black}</span></div>)}</div>
              <div className="rule-block"><h3>02 / Movimentos básicos</h3><p>Rei: 1 casa em qualquer direção. Dama: linhas retas e diagonais. Torre: linhas retas. Bispo: diagonais. Cavalo: salto em L. Peão: avança 1 casa (2 no primeiro lance) e captura na diagonal. Roque, en passant e promoção automática a dama estão ativos. Você nunca pode deixar seu próprio rei em xeque.</p></div>
              <div className="rule-block"><h3>03 / Protocolos ativos</h3><p>Selecione uma peça principal e pressione <strong>Ativar</strong> para ver os destinos da habilidade. Usá-la consome o lance e inicia recarga de 4 turnos próprios. Habilidades não podem deixar seu rei em xeque.</p><div className="ability-list">{(['foundation', 'chaos'] as Side[]).map(side => <div key={side}><div className="ability-faction">{side === 'foundation' ? 'FUNDAÇÃO SCP' : 'ANOMALIAS / INSURGÊNCIA'}</div>{equivalences.filter(x => x.kind !== 'pawn').map(x => <div className="rule-ability" key={`${side}-${x.kind}`}><strong>{names[side][x.kind]}</strong><span>{abilities[side][x.kind].name}: {abilities[side][x.kind].description}</span></div>)}</div>)}</div></div>
              <div className="rule-block"><h3>04 / Blindagem de SCP-682</h3><p>A primeira tentativa válida de capturar SCP-682 apenas remove sua blindagem e consome o turno do atacante. Uma segunda captura válida elimina a peça. A blindagem não se regenera.</p></div>
              <div className="rule-block"><h3>05 / Condições de vitória</h3><p><strong>Xeque-mate:</strong> qualquer lado vence quando o líder inimigo está em xeque sem fuga legal. O xeque-mate do Diretor causa Brecha de Contenção Total.</p><p><strong>Contenção Total:</strong> a Fundação captura pelo menos 2 das 7 anomalias principais e ocupa simultaneamente as celas e5 e d4 ao fim de seu turno.</p><p><strong>Ruptura Total:</strong> a Insurgência ocupa e5 e d4 com anomalias principais ao fim de 2 turnos seus consecutivos. Afogamento é empate.</p></div>
            </div>}
            {tab === 'code' && <div className="panel-body code-panel"><div className="panel-eyebrow">DOCUMENTAÇÃO // IMPLEMENTAÇÃO</div><h2>Motor de movimentos</h2><p className="rules-lead">Exemplo base em Python: classes de peça, movimentos candidatos e filtro de xeque. O jogo interativo desta página usa TypeScript.</p><div className="code-header"><span><Code2 size={15} /> pieces.py</span><button onClick={copyCode}><Clipboard size={14} /> {copied ? 'Copiado' : 'Copiar'}</button></div><pre><code>{pythonCode}</code></pre><p className="code-note">O exemplo é uma base didática. A implementação jogável também inclui roque, en passant, habilidades, recargas e condições de vitória.</p></div>}
          </aside>
        </div>
        <div className="page-footnote"><span>FUNDAÇÃO SCP // DIVISÃO DE SIMULAÇÃO TÁTICA</span><span>CONTER. PROTEGER. JOGAR.</span></div>
      </div>
    </main>
    {confirmResign && <div className="modal-backdrop" onClick={() => setConfirmResign(false)}><div className="confirm-modal" onClick={e => e.stopPropagation()}><div className="modal-icon"><Flag size={23} /></div><h2>Encerrar operação?</h2><p>Desistir concede a vitória à facção adversária. Esta ação não pode ser desfeita.</p><div><button onClick={() => setConfirmResign(false)}>Continuar jogando</button><button onClick={resign}>Desistir da partida</button></div></div></div>}
  </div>;
}
